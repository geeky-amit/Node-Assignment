const arguments = process.argv;

console.log(`Hello ${arguments[2]}`);

console.log(process.argv);
