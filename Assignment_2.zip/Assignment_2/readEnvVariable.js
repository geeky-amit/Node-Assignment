const name = process.env.USERNAME;

console.log(`Hello ${name}`);
